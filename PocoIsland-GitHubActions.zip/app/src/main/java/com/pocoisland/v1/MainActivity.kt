package com.pocoisland.v1

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity: Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,42,28,28); setBackgroundColor(Color.BLACK) }
        fun t(s:String,size:Float)=TextView(this).apply{ text=s; textSize=size; setTextColor(Color.WHITE); setPadding(0,8,0,8)}
        l.addView(t("Poco Island",30f))
        l.addView(t("Functional V1.1 • Music • Calls • Notifications • Charging • Volume",15f))
        fun button(s:String, a:()->Unit){ l.addView(Button(this).apply{ text=s; setOnClickListener{a()} }) }
        button("Enable overlay"){ startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        button("Enable notification access"){ startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        button("Start Poco Island"){ IslandService.start(this) }
        button("Stop Poco Island"){ stopService(Intent(this,IslandService::class.java)) }
        button("Phone permission"){ requestPermissions(arrayOf("android.permission.READ_PHONE_STATE","android.permission.ANSWER_PHONE_CALLS"),10) }
        setContentView(l)
    }
}
