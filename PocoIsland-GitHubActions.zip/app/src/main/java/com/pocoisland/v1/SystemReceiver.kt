package com.pocoisland.v1

import android.content.*
import android.media.AudioManager
import android.os.BatteryManager

class SystemReceiver:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent){
        val x=Intent(c,IslandService::class.java)
        when(i.action){
            Intent.ACTION_BATTERY_CHANGED->{
                val status=i.getIntExtra(BatteryManager.EXTRA_STATUS,-1)
                val level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)
                val scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100)
                val pct=(level*100/scale)
                if(status==BatteryManager.BATTERY_STATUS_CHARGING){
                    x.putExtra("title","⚡ Charging $pct%");x.putExtra("body","");x.putExtra("kind","charge")
                    try{c.startService(x)}catch(_:Exception){}
                }
            }
            "android.media.VOLUME_CHANGED_ACTION"->{
                val stream=i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE",-1)
                if(stream==AudioManager.STREAM_MUSIC){
                    val am=c.getSystemService(AudioManager::class.java)
                    val v=am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val max=am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    x.putExtra("title","🔊 Volume ${v*100/max}%");x.putExtra("body","");x.putExtra("kind","volume")
                    try{c.startService(x)}catch(_:Exception){}
                }
            }
        }
    }
}
