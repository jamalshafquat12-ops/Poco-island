package com.pocoisland.v1

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.concurrent.atomic.AtomicBoolean

class IslandService: Service() {
    companion object {
        const val SHOW="com.pocoisland.SHOW"
        fun start(c:Context){ if(Build.VERSION.SDK_INT>=26)c.startForegroundService(Intent(c,IslandService::class.java)) else c.startService(Intent(c,IslandService::class.java)) }
    }
    private var wm:WindowManager?=null
    private var pill:LinearLayout?=null
    private var text:TextView?=null
    private val h=Handler(Looper.getMainLooper())
    private val expanded=AtomicBoolean(false)

    override fun onCreate(){
        super.onCreate()
        channel()
        startForeground(20, Notification.Builder(this,"island")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Poco Island").setContentText("Running").build())
        if(Settings.canDrawOverlays(this)) show("● Poco Island","Tap for controls",null)
    }
    private fun channel(){ getSystemService(NotificationManager::class.java).createNotificationChannel(
        NotificationChannel("island","Poco Island",NotificationManager.IMPORTANCE_LOW)) }

    override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int {
        if(Settings.canDrawOverlays(this)) {
            val title=i?.getStringExtra("title")
            val body=i?.getStringExtra("body")
            val kind=i?.getStringExtra("kind")
            if(title!=null) show(title,body,kind)
        }
        return START_STICKY
    }

    private fun show(title:String, body:String?, kind:String?){
        h.removeCallbacksAndMessages(null)
        if(pill!=null) try{wm?.removeView(pill)}catch(_:Exception){}
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(22,10,22,10)
            background=GradientDrawable().apply{setColor(Color.BLACK);cornerRadius=80f}
        }
        text=TextView(this).apply{setTextColor(Color.WHITE);textSize=13f;gravity=Gravity.CENTER}
        text!!.text=title + if(body.isNullOrBlank()) "" else "\n$body"
        box.addView(text)
        if(kind=="music"){
            val row=LinearLayout(this).apply{gravity=Gravity.CENTER}
            fun b(label:String, action:()->Unit)=Button(this).apply{ text=label; textSize=10f; setOnClickListener{action()} }
            row.addView(b("◀"){sendMedia{it.transportControls.skipToPrevious()}})
            row.addView(b("▶/Ⅱ"){sendMedia{if(it.playbackState?.state==3)it.transportControls.pause() else it.transportControls.play()}})
            row.addView(b("▶"){sendMedia{it.transportControls.skipToNext()}})
            box.addView(row)
        }
        box.setOnClickListener{ if(kind=="music") expanded.set(!expanded.get()) }
        val p=WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y=12
        pill=box; wm?.addView(box,p)
        h.postDelayed({ pill?.animate()?.alpha(0f)?.setDuration(220)?.start() }, if(kind=="call")12000 else 4500)
    }
    private fun sendMedia(a:(MediaController)->Unit){
        try{
            val m=getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list=m.getActiveSessions(null)
            list.firstOrNull()?.let(a)
        }catch(_:SecurityException){ show("Music access needed","Enable notification access","music") }
    }
    override fun onDestroy(){pill?.let{try{wm?.removeView(it)}catch(_:Exception){}};super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
