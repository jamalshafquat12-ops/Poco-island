package com.pocoisland.v1

import android.content.*
import android.telephony.TelephonyManager

class PhoneReceiver:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent){
        if(i.action!=TelephonyManager.ACTION_PHONE_STATE_CHANGED)return
        val state=i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number=i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Incoming call"
        val x=Intent(c,IslandService::class.java)
        when(state){
            TelephonyManager.EXTRA_STATE_RINGING->{x.putExtra("title","☎ Incoming call");x.putExtra("body",number);x.putExtra("kind","call")}
            TelephonyManager.EXTRA_STATE_OFFHOOK->{x.putExtra("title","☎ Call connected");x.putExtra("body",number);x.putExtra("kind","call")}
            TelephonyManager.EXTRA_STATE_IDLE->{x.putExtra("title","☎ Call ended");x.putExtra("body","");x.putExtra("kind","call")}
            else->return
        }
        try{IslandService.start(c);c.startService(x)}catch(_:Exception){}
    }
}
