package com.pocoisland.v1

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationWatcher: NotificationListenerService(){
    override fun onNotificationPosted(s:StatusBarNotification){
        val e=s.notification.extras
        val title=e.getString("android.title") ?: return
        val body=e.getCharSequence("android.text")?.toString()
        // Ignore Poco Island's own foreground notification.
        if(s.packageName==packageName)return
        val i=android.content.Intent(this,IslandService::class.java).apply{
            putExtra("title","$title");putExtra("body",body);putExtra("kind","notification")
        }
        try{startService(i)}catch(_:Exception){}
    }
}
