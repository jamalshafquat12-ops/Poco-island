# Poco Island — GitHub Actions

1. Create a GitHub account and a new repository named PocoIsland.
2. Upload the CONTENTS of this ZIP into the repository root (not the outer ZIP folder).
3. Make sure `.github/workflows/android.yml` is present.
4. Open Actions → Build Poco Island APK.
5. Click Run workflow if necessary.
6. Open the green completed run.
7. Under Artifacts, download `PocoIsland-debug-apk`.
8. Extract it and install `app-debug.apk` on the POCO X5.
